import torch
import numpy as np

from SCA_Net import attention_SCA

import scipy.io as sio
from torch.utils.data import DataLoader
from torch.utils.data import Dataset
import torchvision.transforms as transforms

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# Import pre-trained weights.
model = attention_SCA().double().to(device)
model.load_state_dict(torch.load("SCA1.pth"))

model.eval()

# Load testdata.mat
mat_data = sio.loadmat('testdata.mat')
# Retrieve data and labels from the dictionary.
data = mat_data['data']
datas = data.reshape(-1, 23, 1, 3)
label = mat_data['labels']
labels = label.squeeze(axis=0)

transform = transforms.Compose([
    transforms.ToTensor()
])

class CustomDataset(Dataset):
    def __init__(self, train_images, transform=None):
        self.images = train_images
        self.transform = transform
    def __getitem__(self, index):
        Image = self.images[index]
        if self.transform is not None:
            image = self.transform(Image)
            x_permuted = image.permute(0, 1, 2)
            return x_permuted
    def __len__(self):
        return len(self.images)

train_dataset = CustomDataset(datas, transform=transform)

dataloader = DataLoader(train_dataset, batch_size=5, shuffle=False)
all_prediction = []
for image in dataloader:
    images = image.double().to(device)
    outputs = model(images)
    _, predicted = torch.max(outputs.data, 1)
    prediction = predicted.flatten().tolist()
    total_sum = sum(prediction)
    label = 1 if total_sum > 2 else 0
    print(label)
    all_prediction.append(label)


# Evalucation matrics
def calculate_metrics(predict_gt, true_gt):
    # TP，FP，FN，TN
    TP = np.logical_and(predict_gt, true_gt).sum()
    print(TP)
    FP = np.logical_and(predict_gt, np.logical_not(true_gt)).sum()
    print(FP)
    FN = np.logical_and(np.logical_not(predict_gt), true_gt).sum()
    print(FN)
    TN = np.logical_and(np.logical_not(predict_gt), np.logical_not(true_gt)).sum()
    print(TN)
    FPR = FP / (FP + TN)
    FNR = FN / (TP + FN)
    TPR = TP / (TP + FN)
    precision = TP / (TP + FP)
    specificity = TN / (TN + FP)
    accuracy = (TP + TN) / (TP + TN + FP + FN)
    f1_score = 2 * (precision * TPR) / (precision + TPR)
    return FPR, FNR, TPR, precision, specificity, accuracy, f1_score


FPR, FNR, TPR, precision, specificity, accuracy, f1_score = calculate_metrics(predict_gt=all_prediction, true_gt=labels)
#
print(f"误报率(FPR):", FPR)
print(f"特异度(specificity)：", specificity)
print(f"漏报率(FNR):", FNR)
print(f"召回率(TPR):", TPR)
print(f"精确率(precision):", precision)
print(f"准确率(accuracy):", accuracy)
print(f"F1 Score(fi_score):", f1_score)

