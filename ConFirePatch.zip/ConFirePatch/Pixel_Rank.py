import numpy as np
import cv2
from Color_Filtering import Color_rule

# Compute bit variance.
def variance_filter(input_array, threshold_array, sizes):
    # Obtain the dimensions of the input image.
    rows, cols = input_array.shape
    variance_map = np.zeros_like(input_array, dtype=np.float32)
    # Scan each pixel.
    for i in range(rows):
        for j in range(cols):
            if threshold_array[i, j] == 1:
                # Extract special window.
                window = input_array[max(0, i - sizes[0] // 2):min(rows, i + sizes[0] // 2 + 1),
                         max(0, j - sizes[1] // 2):min(cols, j + sizes[1] // 2 + 1)]
                variance = np.var(window)
                variance_map[i, j] = variance
    return variance_map

# Merge bit planes.
def bit_combine(YCrCb_image):
    gray_image = YCrCb_image[:, :, 0]

    bit1_plane = gray_image & 1
    bit2_plane = (gray_image >> 1) & 1
    bit3_plane = (gray_image >> 2) & 1

    merged_values = (bit3_plane << 2) | (bit2_plane << 1) | bit1_plane
    return merged_values

# Rank pixels from high to low.
def rank(rgb_image):
    YCrCb_image = cv2.cvtColor(rgb_image, cv2.COLOR_RGB2YCrCb)
    filtered_image = Color_rule(rgb_image)
    merged_values = bit_combine(YCrCb_image)
    variance_map = variance_filter(merged_values, filtered_image, sizes=(7, 7))
    # Index squence.
    sorted_indices = np.argsort(variance_map.ravel())[::-1]
    return sorted_indices