import numpy as np
from skimage.util import view_as_windows
from Pixel_Rank import rank

# Expand RGB channels.
def expand_channels(rgb_image, p_r, w_r):
    r_channel = rgb_image[:, :, 0]
    g_channel = rgb_image[:, :, 1]
    b_channel = rgb_image[:, :, 2]
    R_ext = np.pad(r_channel, ((p_r + w_r, p_r + w_r), (p_r + w_r, p_r + w_r)), mode='reflect').astype(np.float64)
    G_ext = np.pad(g_channel, ((p_r + w_r, p_r + w_r), (p_r + w_r, p_r + w_r)), mode='reflect').astype(np.float64)
    B_ext = np.pad(b_channel, ((p_r + w_r, p_r + w_r), (p_r + w_r, p_r + w_r)), mode='reflect').astype(np.float64)
    return R_ext, G_ext, B_ext

# Extract central patch.
def extract_min_block(R_ext, G_ext, B_ext, row_ext, col_ext, rows_ext, cols_ext, p_r):
    # Ensure that the coordinates do not exceed the boundaries of the expanded image.
    start_row1 = max(0, row_ext - p_r)
    end_row1 = min(rows_ext, row_ext + p_r + 1)
    start_col1 = max(0, col_ext - p_r)
    end_col1 = min(cols_ext, col_ext + p_r + 1)
    R_block = R_ext[start_row1:end_row1, start_col1:end_col1]
    G_block = G_ext[start_row1:end_row1, start_col1:end_col1]
    B_block = B_ext[start_row1:end_row1, start_col1:end_col1]
    return R_block, G_block, B_block

# Extract neighboring window.
def extract_max_block(R_ext, G_ext, B_ext, row_ext, col_ext, rows_ext, cols_ext, p_r, w_r):
    start_row2 = max(0, row_ext - p_r - w_r)
    end_row2 = min(rows_ext, row_ext + p_r + w_r + 1)
    start_col2 = max(0, col_ext - p_r - w_r)
    end_col2 = min(cols_ext, col_ext + p_r + w_r + 1)
    R_range = R_ext[start_row2:end_row2, start_col2:end_col2]
    G_range = G_ext[start_row2:end_row2, start_col2:end_col2]
    B_range = B_ext[start_row2:end_row2, start_col2:end_col2]
    return R_range, G_range, B_range

# Compute context.
def H_calculation(R_block, G_block, B_block, R_range, G_range, B_range, window_size, sigma, bins, p_r, w_r):
    min = (p_r * 2) + 1
    max = (((p_r + w_r) * 2) + 1) - (min - 1)
    # Ensure that the coordinates do not exceed the boundaries of the expanded image.
    windows_R = view_as_windows(R_range, window_size)
    windows_G = view_as_windows(G_range, window_size)
    windows_B = view_as_windows(B_range, window_size)
    flattened_patches_R = windows_R.reshape(max * max, min * min).T
    flattened_patches_G = windows_G.reshape(max * max, min * min).T
    flattened_patches_B = windows_B.reshape(max * max, min * min).T
    # Broadcast.
    patchR_flat = R_block.flatten()[:, np.newaxis]
    patchG_flat = G_block.flatten()[:, np.newaxis]
    patchB_flat = B_block.flatten()[:, np.newaxis]
    surf_neg_R = -np.sum((patchR_flat - flattened_patches_R) ** 2, axis=0) / (2 * sigma ** 2)
    surf_neg_G = -np.sum((patchG_flat - flattened_patches_G) ** 2, axis=0) / (2 * sigma ** 2)
    surf_neg_B = -np.sum((patchB_flat - flattened_patches_B) ** 2, axis=0) / (2 * sigma ** 2)
    surf_R = np.exp(surf_neg_R)
    surf_G = np.exp(surf_neg_G)
    surf_B = np.exp(surf_neg_B)
    # Compute histogram bin.
    bin_edges = np.linspace(0, 1, bins + 1, endpoint=True)
    histR, _ = np.histogram(surf_R, bins=bin_edges)
    histG, _ = np.histogram(surf_G, bins=bin_edges)
    histB, _ = np.histogram(surf_B, bins=bin_edges)
    # Normalize.
    patchR_normalized = R_block.ravel() / 255.0
    patchG_normalized = G_block.ravel() / 255.0
    patchB_normalized = B_block.ravel() / 255.0
    h_R = histR.ravel() / histR.sum()
    h_G = histG.ravel() / histG.sum()
    h_B = histB.ravel() / histB.sum()
    vector_R = np.concatenate((patchR_normalized, h_R))
    vector_G = np.concatenate((patchG_normalized, h_G))
    vector_B = np.concatenate((patchB_normalized, h_B))
    patchR_2d = vector_R[:, np.newaxis]
    patchG_2d = vector_G[:, np.newaxis]
    patchB_2d = vector_B[:, np.newaxis]
    new_patch = np.dstack((patchR_2d, patchG_2d, patchB_2d))
    return new_patch

def Key_Patch(rgb_image, p_r, w_r, num, sigma, bins):
    rows, cols, _ = rgb_image.shape
    size = (p_r * 2) + 1
    R_ext, G_ext, B_ext = expand_channels(rgb_image, p_r, w_r)
    sorted_indices = rank(rgb_image)
    # Select key pixel.
    top_five_indices = sorted_indices[:num]
    sorted_row_indices, sorted_col_indices = np.unravel_index(top_five_indices, (rows, cols))
    pad_size = p_r + w_r
    rows_ext = rows + 2 * pad_size
    cols_ext = cols + 2 * pad_size
    patchs = []
    for row, col in zip(sorted_row_indices, sorted_col_indices):
        # Calculate the coordinates after expansion.
        row_ext = row + pad_size
        col_ext = col + pad_size
        R_block, G_block, B_block = extract_min_block(R_ext, G_ext, B_ext, row_ext, col_ext, rows_ext, cols_ext, p_r)
        R_range, G_range, B_range = extract_max_block(R_ext, G_ext, B_ext, row_ext, col_ext, rows_ext, cols_ext, p_r, w_r)
        new_patch = H_calculation(R_block, G_block, B_block, R_range, G_range, B_range, (size, size), sigma, bins, p_r, w_r)
        patchs.append(new_patch)
    return patchs
