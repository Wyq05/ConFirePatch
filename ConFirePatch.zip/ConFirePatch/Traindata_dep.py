import cv2
from scipy.io import savemat
import csv
from Context_Key_Patch import Key_Patch

trainset_path = "D:/DataSet2/BoWFire/trainset/"
csv_file_path = "D:/DataSet2/BoWFire/trainset/trainset.csv"

# Define two empty lists.
train_images = []
train_labels = []

with open(csv_file_path, "r") as file:
    csv_reader = csv.reader(file)
    for row in csv_reader:
        image_path = row[0]
        label = row[1]
        label = label.replace("\t", "")
        if label in ["fire", "normal"]:
            clean_image_path = image_path.rstrip()
            # Data path.
            full_path = trainset_path + clean_image_path
            image = cv2.imread(full_path, cv2.IMREAD_COLOR)
            rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            if label == "fire":
                labels = 1
            elif label == "normal":
                labels = 0
            data = Key_Patch(rgb_image, p_r=1, w_r=1, num=5, sigma=10, bins=10)
            # Expand labels.
            expanded_label = [labels for _ in range(5)]
            train_images.append(data)
            train_labels.append(expanded_label)

flat_image = [array for sublist in train_images for array in sublist]
flat_label = [array for sublist in train_labels for array in sublist]
data_dict = {'data': flat_image, 'label': flat_label}
# Save the processed data.
savemat('traindata.mat', data_dict)
print()
