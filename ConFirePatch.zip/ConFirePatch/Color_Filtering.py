import cv2
import numpy as np
from scipy.ndimage import generic_filter

def kernal(kernal_size):
    def fire_filter(window):
        center_id = ((kernal_size ** 2) - 1)//2
        # Retrieve the value of the central pixel.
        center = window[center_id]
        # Check the labels of neighboring pixels.
        num_neighbors = (window[:center_id] + window[center_id + 1:]).sum()
        return 1 if center == 1 and num_neighbors >= (center_id-1) else 0
    return fire_filter

# Color filtering.
def Color_rule(rgb_image):
    YCrCb_image = cv2.cvtColor(rgb_image, cv2.COLOR_RGB2YCrCb)
    YCrCb_image_clip = np.clip(YCrCb_image, [16, 16, 16], [235, 240, 240])
    y_channels, cr_channels, cb_channels = YCrCb_image_clip[:, :, 0], YCrCb_image_clip[:, :, 1], YCrCb_image_clip[:, :, 2]
    # Set threshold.
    mask = (y_channels > cb_channels) & (np.abs(cr_channels - cb_channels) >= 40)
    binary_image = np.zeros(YCrCb_image_clip.shape[:2], dtype=np.uint8)
    # Label the pixels that meet the rule.
    binary_image[mask] = 1
    fire_filter_func = kernal(3)
    # Apply a custom filter.
    filtered_image = generic_filter(binary_image, function=fire_filter_func, size=(3, 3), mode='reflect')
    return filtered_image


