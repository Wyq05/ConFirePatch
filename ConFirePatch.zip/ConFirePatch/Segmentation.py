import torch
import cv2
from skimage.util import view_as_windows
import numpy as np
from SCA_Net import attention_SCA
from torch.utils.data import DataLoader
from torch.utils.data import Dataset
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
from Color_Filtering import Color_rule

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

model = attention_SCA().double().to(device)
model.load_state_dict(torch.load("SCA.pth"))

model.eval()

testset_img_path = "D:/DataSet2/BoWFire/testset/img"
testset_gt_path = "D:/DataSet2/BoWFire/testset/gt"

# Input a image.
filename = "fire017"
image = cv2.imread(testset_img_path + "/" + filename + ".png", cv2.IMREAD_COLOR)
gt_img = cv2.imread(testset_gt_path + "/" + filename + "_gt.png", cv2.IMREAD_GRAYSCALE)
rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
binary_img = Color_rule(rgb_image)

indices = np.argwhere(binary_img == 1)

# Expand RGB channels.
def expand_channels(rgb_image, p_r, w_r):
    r_channel = rgb_image[:, :, 0]
    g_channel = rgb_image[:, :, 1]
    b_channel = rgb_image[:, :, 2]
    R_ext = np.pad(r_channel, ((p_r + w_r, p_r + w_r), (p_r + w_r, p_r + w_r)), mode='reflect').astype(np.float64)
    G_ext = np.pad(g_channel, ((p_r + w_r, p_r + w_r), (p_r + w_r, p_r + w_r)), mode='reflect').astype(np.float64)
    B_ext = np.pad(b_channel, ((p_r + w_r, p_r + w_r), (p_r + w_r, p_r + w_r)), mode='reflect').astype(np.float64)
    return R_ext, G_ext, B_ext

# Extract patch.
def extract_min_block(R_ext, G_ext, B_ext, row_ext, col_ext, rows_ext, cols_ext, p_r):
    start_row1 = max(0, row_ext - p_r)
    end_row1 = min(rows_ext, row_ext + p_r + 1)
    start_col1 = max(0, col_ext - p_r)
    end_col1 = min(cols_ext, col_ext + p_r + 1)

    R_block = R_ext[start_row1:end_row1, start_col1:end_col1]
    G_block = G_ext[start_row1:end_row1, start_col1:end_col1]
    B_block = B_ext[start_row1:end_row1, start_col1:end_col1]
    return R_block, G_block, B_block

# Extract neighboring window.
def extract_max_block(R_ext, G_ext, B_ext, row_ext, col_ext, rows_ext, cols_ext, p_r, w_r):
    start_row2 = max(0, row_ext - p_r - w_r)
    end_row2 = min(rows_ext, row_ext + p_r + w_r + 1)
    start_col2 = max(0, col_ext - p_r - w_r)
    end_col2 = min(cols_ext, col_ext + p_r + w_r + 1)

    R_range = R_ext[start_row2:end_row2, start_col2:end_col2]
    G_range = G_ext[start_row2:end_row2, start_col2:end_col2]
    B_range = B_ext[start_row2:end_row2, start_col2:end_col2]
    return R_range, G_range, B_range

# Compute contexts.
def H_calculation(R_block, G_block, B_block, R_range, G_range, B_range, window_size, sigma, bins, p_r, w_r):
    min = (p_r * 2) + 1
    max = (((p_r + w_r) * 2) + 1) - (min - 1)
    windows_R = view_as_windows(R_range, window_size)
    windows_G = view_as_windows(G_range, window_size)
    windows_B = view_as_windows(B_range, window_size)
    flattened_patches_R = windows_R.reshape(max * max, min * min).T
    flattened_patches_G = windows_G.reshape(max * max, min * min).T
    flattened_patches_B = windows_B.reshape(max * max, min * min).T
    # Boradcast
    patchR_flat = R_block.flatten()[:, np.newaxis]
    patchG_flat = G_block.flatten()[:, np.newaxis]
    patchB_flat = B_block.flatten()[:, np.newaxis]
    surf_neg_R = -np.sum((patchR_flat - flattened_patches_R) ** 2, axis=0) / (2 * sigma ** 2)
    surf_neg_G = -np.sum((patchG_flat - flattened_patches_G) ** 2, axis=0) / (2 * sigma ** 2)
    surf_neg_B = -np.sum((patchB_flat - flattened_patches_B) ** 2, axis=0) / (2 * sigma ** 2)
    surf_R = np.exp(surf_neg_R)
    surf_G = np.exp(surf_neg_G)
    surf_B = np.exp(surf_neg_B)
    # Calculate histogram bin
    bin_edges = np.linspace(0, 1, bins + 1, endpoint=True)
    histR, _ = np.histogram(surf_R, bins=bin_edges)
    histG, _ = np.histogram(surf_G, bins=bin_edges)
    histB, _ = np.histogram(surf_B, bins=bin_edges)
    # Normalize
    patchR_normalized = R_block.ravel() / 255.0
    patchG_normalized = G_block.ravel() / 255.0
    patchB_normalized = B_block.ravel() / 255.0

    h_R = histR.ravel() / histR.sum()
    h_G = histG.ravel() / histG.sum()
    h_B = histB.ravel() / histB.sum()
    vector_R = np.concatenate((patchR_normalized, h_R))
    vector_G = np.concatenate((patchG_normalized, h_G))
    vector_B = np.concatenate((patchB_normalized, h_B))
    patchR_2d = vector_R[:, np.newaxis]
    patchG_2d = vector_G[:, np.newaxis]
    patchB_2d = vector_B[:, np.newaxis]
    new_patch = np.dstack((patchR_2d, patchG_2d, patchB_2d))
    return new_patch

p_r = 1
w_r = 9
sigma = 10
bins = 14

data = []
for index in indices:
    # Achieve expanded RGB channels.
    R_ext, G_ext, B_ext = expand_channels(rgb_image, p_r, w_r)
    rows, cols, _ = rgb_image.shape
    size = (p_r * 2) + 1
    pixel_value = rgb_image[index[0], index[1]]
    # Calculate the expanded image dimensions.
    pad_size = p_r + w_r
    rows_ext = rows + 2 * pad_size
    cols_ext = cols + 2 * pad_size
    # Calculate the corresponding coordinates.
    row_ext = index[0] + pad_size
    col_ext = index[1] + pad_size
    R_block, G_block, B_block = extract_min_block(R_ext, G_ext, B_ext, row_ext, col_ext, rows_ext, cols_ext, p_r)
    R_range, G_range, B_range = extract_max_block(R_ext, G_ext, B_ext, row_ext, col_ext, rows_ext, cols_ext, p_r, w_r)
    new_patch = H_calculation(R_block, G_block, B_block, R_range, G_range, B_range, (size, size), sigma, bins, p_r, w_r)
    data.append(new_patch)

transform = transforms.Compose([
    transforms.ToTensor()
])

# Define a class for image processing.
class CustomDataset(Dataset):
    def __init__(self, train_images, transform=None):
        self.images = train_images
        self.transform = transform
    def __getitem__(self, index):
        Image = self.images[index]
        if self.transform is not None:
            image = self.transform(Image)
            x_permuted = image.permute(0, 1, 2)
            return x_permuted
    def __len__(self):
        return len(self.images)

train_dataset = CustomDataset(data, transform=transform)
# Load data
dataloader = DataLoader(train_dataset, batch_size=4000, shuffle=False)

height, width, _ = rgb_image.shape

predictions = []
for image in dataloader:
    images = image.double().to(device)
    outputs = model(images)
    _, predicted = torch.max(outputs.data, 1)
    prediction = predicted.flatten().tolist()
    print(prediction)
    predictions.append(prediction)

flat_list = [item for sublist in predictions for item in sublist]
del data
for index, value in zip(indices, flat_list):
    i, j = index
    binary_img[i][j] = value
# Resize
expanded_predictions_array = np.repeat(binary_img[:, :, np.newaxis], 3, axis=2)
# Segmented image
final_image = rgb_image * expanded_predictions_array
# gt
gt_pre = binary_img.astype(np.uint8)

# Calculate evaluation matrics.
def calculate_metrics(predict_gt, true_gt):
    # TP，FP，FN，TN
    TP = np.logical_and(predict_gt, true_gt).sum()
    print(TP)
    FP = np.logical_and(predict_gt, np.logical_not(true_gt)).sum()
    print(FP)
    FN = np.logical_and(np.logical_not(predict_gt), true_gt).sum()
    print(FN)
    TN = np.logical_and(np.logical_not(predict_gt), np.logical_not(true_gt)).sum()
    print(TN)

    FPR = FP / (FP + TN)
    FNR = FN / (TP + FN)
    TPR = TP / (TP + FN)
    precision = TP / (TP + FP)
    specificity = TN / (TN + FP)
    accuracy = (TP + TN) / (TP + TN + FP + FN)
    f1_score = 2 * (precision * TPR) / (precision + TPR)
    return FPR, FNR, TPR, precision, specificity, accuracy, f1_score

plt.figure(figsize=(width/100, height/100))
plt.imshow(final_image)
plt.axis('off')
plt.savefig('Segment_image', dpi=300, bbox_inches='tight', pad_inches=0)

#
plt.figure(figsize=(width/100, height/100))
plt.imshow(gt_pre, cmap="gray")
plt.axis('off')
plt.savefig('Segment_gt', dpi=300, bbox_inches='tight', pad_inches=0)
# plt.axis("off")
plt.show()

FPR, FNR, TPR, precision, specificity, accuracy, f1_score = calculate_metrics(predict_gt=gt_pre, true_gt=gt_img)

print(f"误报率(FPR):", FPR)
print(f"特异度(specificity)：", specificity)
print(f"漏报率(FNR):", FNR)
print(f"召回率(TPR):", TPR)
print(f"精确率(precision):", precision)
print(f"准确率(accuracy):", accuracy)
print(f"F1 Score(fi_score):", f1_score)