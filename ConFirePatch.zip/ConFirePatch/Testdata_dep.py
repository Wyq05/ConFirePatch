from scipy.io import savemat
import csv
import cv2
from Context_Key_Patch import Key_Patch

trainset_path = "D:/DataSet2/BoWFire/vailset/"
csv_file_path = "D:/DataSet2/BoWFire/vailset/vailset.csv"

# Define two empty lists.
tests_images = []
tests_labels = []
with open(csv_file_path, "r", encoding='cp1252') as file:
    csv_reader = csv.reader(file)
    for row in csv_reader:
        image_path = row[0]
        label = row[1]
        label = label.replace("\t", "")
        if label in ["fire", "not_fire"]:
            clean_image_path = image_path.rstrip()
            full_path = trainset_path + clean_image_path
            image = cv2.imread(full_path, cv2.IMREAD_COLOR)
            rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            if label == "fire":
                labels = 1
            elif label == "not_fire":
                labels = 0
            data = Key_Patch(rgb_image, p_r=1, w_r=9, num=5, sigma=10, bins=18)
            tests_images.append(data)
            tests_labels.append(labels)

# Create a dictionary to store data and labels.
data_dict = {'data': tests_images, 'labels': tests_labels}
savemat('testdata.mat', data_dict)