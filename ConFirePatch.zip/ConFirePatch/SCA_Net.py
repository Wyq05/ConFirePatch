import torch.nn as nn
import torch

class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=1):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        # 利用1x1卷积代替全连接
        self.fc1   = nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False)
        self.relu1 = nn.ReLU()
        self.fc2   = nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
        out = avg_out + max_out
        return self.sigmoid(out)

class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1
        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)
        return self.sigmoid(x)

class sca_block(nn.Module):
    def __init__(self, channel, ratio=1, kernel_size=7):
        super(sca_block, self).__init__()
        self.channelattention = ChannelAttention(in_planes=channel, ratio=ratio)
        self.spatialattention = SpatialAttention(kernel_size=kernel_size)

    def forward(self, x):
        x = x * self.channelattention(x)
        x = x * self.spatialattention(x)
        return x

class attention_SCA(nn.Module):
    def __init__(self, in_channels=3):
        super(attention_SCA, self).__init__()
        self.sca_blocks = sca_block(channel=in_channels, ratio=1)
        self.conv1 = nn.Conv2d(in_channels=3, out_channels=6, kernel_size=1, stride=1, padding=1)
        self.relu1 = nn.ReLU6(inplace=True)
        self.pool2 = nn.MaxPool2d(kernel_size=2, stride=1, padding=1)
        self.conv3 = nn.Conv2d(in_channels=6, out_channels=36, kernel_size=3, stride=2, padding=1)
        self.relu2 = nn.ReLU6(inplace=True)
        self.pool4 = nn.MaxPool2d(kernel_size=2, stride=2, padding=1)
        self.conv5 = nn.Conv2d(in_channels=36, out_channels=12, kernel_size=1, stride=1, padding=0)
        self.bn6 = nn.BatchNorm2d(12)
        self.dropout = nn.Dropout(0.2)
        self.liner8 = nn.Linear(168, 32)
        self.liner9 = nn.Linear(32, 2)
        self.sigmoid = nn.Sigmoid()
    def forward(self, x):
        x = self.sca_blocks(x)
        x = self.conv1(x)
        x = self.relu1(x)
        x = self.pool2(x)
        x = self.conv3(x)
        x = self.relu2(x)
        x = self.pool4(x)
        x = self.conv5(x)
        x = self.bn6(x)
        x = x.view(x.size(0), -1)
        x = self.dropout(x)
        x = self.liner8(x)
        x = self.liner9(x)
        return self.sigmoid(x)

