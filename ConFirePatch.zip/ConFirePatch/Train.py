import torch.nn as nn
import torch
import scipy.io as sio
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.utils.data import Dataset
import torchvision.transforms as transforms

from SCA_Net import attention_SCA

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = attention_SCA().double().to(device)

mat_data = sio.loadmat('traindata.mat')
data = mat_data['data']
label = mat_data['label']
labels = label.squeeze(axis=0)

transform = transforms.Compose([
    transforms.ToTensor()
])

class CustomDataset(Dataset):
    def __init__(self, train_images, train_labels, transform=None):
        self.images = train_images
        self.labels = train_labels
        self.transform = transform
    def __getitem__(self, index):
        Image = self.images[index]
        Label = self.labels[index]
        Labels = int(Label)
        label_one_hot = F.one_hot(torch.tensor(Labels), num_classes=2)
        if self.transform is not None:
            image = self.transform(Image)
            x_permuted = image.permute(0, 1, 2)
            return x_permuted, label_one_hot
    def __len__(self):
        return len(self.images)

train_dataset = CustomDataset(data, labels, transform=transform)
dataloader = DataLoader(train_dataset, batch_size=250, shuffle=True)

# Binary Cross-Entropy Loss Function.
# Define the loss function and optimizer.
criterion = nn.BCELoss().to(device)
optimizer = optim.Adam(model.parameters(), lr=0.001)

num_epochs = 240

for epoch in range(num_epochs):
    model.train()
    running_loss = 0.0
    train_correct = 0
    train_total = 0
    train_accuracy = 0.0
    for inputs, labels in dataloader:
        inputs = inputs.to(torch.float64).to(device)
        labels = labels.to(torch.float64).to(device)
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels.double())
        loss.backward()
        optimizer.step()
        running_loss += loss.item()
        _, predicted = torch.max(outputs.data, 1)
        _, label = torch.max(labels, 1)
        train_total += label.size(0)
        train_correct += torch.count_nonzero(torch.eq(predicted, label)).item()
        train_accuracy = train_correct / train_total
        train_average_loss = running_loss / len(dataloader)
    print(f"Epoch {epoch + 1}, Loss: {running_loss / len(dataloader)}")
    print(f"Epoch {epoch + 1}, Accuary: {train_accuracy * 100:.2f}%")
model = model.to("cpu")
torch.save(model.state_dict(), "SCA1.pth")
